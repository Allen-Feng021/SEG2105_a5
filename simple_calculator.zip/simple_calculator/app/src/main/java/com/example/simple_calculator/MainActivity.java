package com.example.simple_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Stack;

public class MainActivity extends AppCompatActivity {
    TextView scrn;
     Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,
             add,sub,mul,div,clr,norm,eql,del,pwr,dec;
    private Stack<Double> operandStack = new Stack<>();
    private Stack<String> operatorStack = new Stack<>();
    private Stack<String> stack = new Stack<>();
    String finalR ="";
    private double result = 0.0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn0 = (Button)findViewById(R.id.btn0);
        btn1 = (Button)findViewById(R.id.btn1);
        btn2 = (Button)findViewById(R.id.btn2);
        btn3 = (Button)findViewById(R.id.btn3);
        btn4 = (Button)findViewById(R.id.btn4);
        btn5 = (Button)findViewById(R.id.btn5);
        btn6 = (Button)findViewById(R.id.btn6);
        btn7 = (Button)findViewById(R.id.btn7);
        btn8 = (Button)findViewById(R.id.btn8);
        btn9 = (Button)findViewById(R.id.btn9);
        add = (Button)findViewById(R.id.add);
        sub = (Button)findViewById(R.id.sub);
        mul = (Button)findViewById(R.id.mul);
        div = (Button)findViewById(R.id.div);
        clr = (Button)findViewById(R.id.clr);
        norm = (Button)findViewById(R.id.norm);
        eql = (Button)findViewById(R.id.eql);
        del = (Button)findViewById(R.id.del);
        pwr = (Button)findViewById(R.id.pwr);
        dec = (Button)findViewById(R.id.dec);
        scrn = (TextView)findViewById(R.id.screen);

        btn0.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"0");stack.push("0");}});
        btn1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"1");stack.push("1");}});
        btn2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"2");stack.push("2");}});
        btn3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"3");stack.push("3");}});
        btn4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"4");stack.push("4");}});
        btn5.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"5");stack.push("5");}});
        btn6.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"6");stack.push("6");}});
        btn7.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"7");stack.push("7");}});
        btn8.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"8");stack.push("8");}});
        btn9.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"9");stack.push("9");}});
        add.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"+");stack.push("+");}});
        sub.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"-");stack.push("-");}});
        mul.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"*");stack.push("*");}});
        div.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"/");stack.push("/");}});
        norm.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"%");stack.push("%");}});

        del.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { if (!stack.isEmpty()) stack.pop() ;
                                             String str = stackString(); scrn.setText(str); }});
        pwr.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+"^");stack.push("^");}});
        dec.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText(scrn.getText()+".");stack.push(".");}});

        clr.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { scrn.setText("");stack.clear();}});
        eql.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) { calculator();
                if (finalR==null) scrn.setText("Invalid expression"); finalR="";  }});
    }
    /*
     * input pamameters ((double, double,String)
     * the operations add ,sub,div,mul, power and model
     * return double
     * note: % operation for integer
     * */
    private double arith(double op1, double op2,String operator) {
        switch (operator) {
            case "+" : return (op1+op2);
            case "-" : return (op1-op2);
            case "*": return (op1*op2);
            case "/": return (op1/op2);
            case "%": return ((int)op1%(int)op2);
            case "^": return  (double)Math.pow(op1,op2);
        }
        return 0.0;
    }

    /*input(nothing);
     *return final result;
     */
    public double finalResult() {return result;}
    /*input no parameter
     *the arithmetic expression in stack.
     *this method implements the all functions
     *the method analysis the arithmetic expression .
     * Analysing the operand and operators are processing
     * simultaneously  .
     * if reading number char, transform it into number  and
     * form a double number ,then push it operandStack;
     * the operator is encountered, push it to operatorStack
     * or compare it with the top operator of operatorStack
     * if priority is higher, operating and result is stacked
     * into operandStack.
     * */
    private void calculator() {
        //take the length of arithmetic expression
        int s = stack.size();
        //declare  tree operands
        //rspectively store first operand ,second operand
        //and operating result.
        double opd1,opd2,result;
        //this opd is for forming the entire double number one by one bit.
        double opd=0;
        //operator symbol
        String optr="";
        //it is for forming operands.
        boolean firstNum = false;
        //it is for forming the decimal parts.
        double decimal =1 ;
        //it is for forming the decimal parts.
        boolean decimalPart = false;

        operandStack.clear();
        operatorStack.clear();

        // analusing the arithmetic expression one by one bit
        for(int i=0;i<s;i++) {
            switch (stack.get(i)) {
                //add and sub have same priority level;
                //push opd formed into operandStack; firstNumber =0
                //finished the combining of a operand.
                case "-":
                case "+": if (firstNum) { operandStack.push(opd);opd=0; firstNum = false;decimalPart = false;}
                    //when operatorStack.isEmpty() is false,take second oprand and then
                    // take first perand and the computer ,result pushed into operandStack.
                    while(!operatorStack.isEmpty()) {
                        if(!operandStack.isEmpty())  {
                            opd2=(double)operandStack.pop();
                        }else {
                            showInfo("Expression Error!");
                            return;}
                        if(!operandStack.isEmpty())  {
                            opd1=(double)operandStack.pop();
                        }else {showInfo("Expression Error!");
                            return;}

                        optr= operatorStack.pop();
                        operandStack.push(arith(opd1,opd2,optr));
                    }
                    operatorStack.push(stack.get(i));
                    break;
                //"*","/" and "%"  have same priority level;
                case "*":
                case "/":
                case "%":
                    //push opd formed into operandStack; firstNumber =0
                    //finished the combining of a operand.
                    if (firstNum) { operandStack.push(opd);opd=0; firstNum = false;decimalPart = false;}
                    //when operatorStack.isEmpty() is false,take second oprand and then
                    // take first perand and the computer ,result pushed into operandStack.
                    while (!(operatorStack.isEmpty())&&("*/%^".contains(operatorStack.peek()))) {
                        if(!operandStack.isEmpty())  {opd2=(double)operandStack.pop();
                        }else {showInfo("Expression Error!"); return;}
                        if(!operandStack.isEmpty())  {opd1=(double)operandStack.pop();
                        }else {showInfo("Expression Error!"); return;}

                        optr= operatorStack.pop();
                        //process the case of devid as zero
                        if (("/%".contains(optr))&&(opd2==0)) {
                            String st = stackString()+" 0 as divisor !";
                            scrn.setText(st);
                            operandStack.clear();
                            operatorStack.clear();
                            stack.clear();
                            return;
                        }
                        operandStack.push(arith(opd1,opd2,optr));
                    }

                    operatorStack.push(stack.get(i));
                    break;
                //"^"  has the highest priority level;
                case "^":
                    //push opd formed into operandStack; firstNumber =0
                    //finished the combining of a operand.
                    if (firstNum) { operandStack.push(opd);opd=0; firstNum = false;decimalPart = false;}
                    //when operatorStack.isEmpty() is false,take second oprand and then
                    // take first perand and the computer ,result pushed into operandStack.
                    while (!(operatorStack.isEmpty())&&("^".equals(operatorStack.peek()))) {
                        if(!operandStack.isEmpty())  {opd2=(double)operandStack.pop();
                        }else {showInfo("Expression Error!"); return;}
                        if(!operandStack.isEmpty())  {opd1=(double)operandStack.pop();
                        }else {showInfo("Expression Error!"); return;}

                        optr= operatorStack.pop();
                        operandStack.push(arith(opd1,opd2,optr));
                    }
                    operatorStack.push(stack.get(i));
                    break;
                //if encounted ".", decimalPart=true.
                //next combine the decimal parts .
                //first number *0.1 ,add the original integer part.
                //second number * 0.01 ....   ;    decimal=0.1 ,
                case ".": if (!decimalPart) {decimalPart=true; decimal=0.1 ;break;
                }else {showInfo("double '.'");break;}
                default:
                    if (firstNum) {
                        if (!decimalPart)
                            opd = opd*10+Integer.parseInt(stack.get(i));
                        else {
                            opd = opd+Integer.parseInt(stack.get(i))*decimal;
                            decimal=decimal*0.1;
                        }
                    }else {
                        opd = Integer.parseInt(stack.get(i));
                        firstNum = true;
                    }
            }
        }
        if (firstNum) {operandStack.push(opd);opd=0;firstNum = false;}
        while (!operatorStack.isEmpty()) {
            if(!operandStack.isEmpty())  {opd2=(double)operandStack.pop();
            }else {showInfo("Expression Error!"); return;}
            if(!operandStack.isEmpty())  {opd1=(double)operandStack.pop();
            }else {showInfo("Expression Error!"); return;}

            optr= operatorStack.pop();
            if (("/%".contains(optr))&&(opd2==0)) {
                showInfo(" 0 as divisor !");
                operandStack.clear();
                operatorStack.clear();
                stack.clear();
                return;
            }
            operandStack.push(arith(opd1,opd2,optr));
        }
        // show the result in TextField and clear three stacks
        /* when last result is not clear, it becomes  as the operand next time.
         * So it has to be transformed into stack (store original arithmetic
         * expresiion.
         * when last result is cleared, it has to clear the screen on textField
         * and tree stacks is also cleared (including operandStack ,operatorStack
         * and stack
         *
         * */
        if (!operandStack.isEmpty()) {
            String st=""+operandStack.pop();
            showInfo(st);
            stack.clear();
            //the operand left from operandStack into stack as next operand
            for(int i=0;i<st.length();i++)
            { String str =""+st.charAt(i);
                stack.push(str);		}
        } else {stack.clear();}
        // clear tree stack;
        //stack.clear();
        // operandStack.clear();
        // operatorStack.clear();
    }
    private void showInfo(String str) {
        scrn.setText("");
        scrn.setText(str);
    }

    //combine an arithmetic expression into the string to process
    private String stackString() {
        String st="";
        for(int i=0;i<stack.size();i++) {
            st += stack.get(i);
        }
        return st;
    }

}
